# Plan: 50+ Language Support for Infinity Build — Complete Replacement of RESULTS-QUALITY-AUDIT.md

## Context

Infinity Build currently supports **only 7 JavaScript/TypeScript frameworks** (nextjs, astro, remix, vite-react, sveltekit, vue-nuxt, solidstart) via a framework adapter system. The user wants to expand this to **50+ programming languages** (per TIOBE/GitHub rankings) to make Infinity Build genuinely multi-language.

This plan replaces the entire `RESULTS-QUALITY-AUDIT.md` with a comprehensive roadmap for multi-language support, covering:
- Language detection per language
- Scaffold templates per language
- Build/test/lint commands per language
- Verification pipelines per language
- System prompts per language with quality standards
- Extension points in existing architecture

---

## Top 50 Languages by Popularity (TIOBE + GitHub 2024)

### Tier 1: Core Web Languages (Already Partially Supported)
| Rank | Language | Current Support | Framework Ecosystem |
|------|----------|-----------------|---------------------|
| 1 | JavaScript/TypeScript | ✅ 7 frameworks | React, Vue, Svelte, Solid, Next, Astro, Remix |
| 2 | Python | ❌ | Django, FastAPI, Flask, Streamlit, NiceGUI |
| 3 | Java | ❌ | Spring Boot, Quarkus, Micronaut, JHipster |
| 4 | C# | ❌ | ASP.NET Core, Blazor, MAUI, Uno Platform |
| 5 | Go | ❌ | Gin, Echo, Fiber, Go Fiber, Wails |
| 6 | Rust | ❌ | Actix, Axum, Rocket, Leptos, Dioxus, Tauri |
| 7 | PHP | ❌ | Laravel, Symfony, Slim, Lumen |
| 8 | Ruby | ❌ | Rails, Sinatra, Hanami |
| 9 | Swift | ❌ | Vapor, Hummingbird, SwiftUI, SwiftWebUI |
| 10 | Kotlin | ❌ | Ktor, Spring Boot, Compose Multiplatform |

### Tier 2: Strong Ecosystems (High Priority)
| Rank | Language | Framework Ecosystem |
|------|----------|---------------------|
| 11 | C++ | ❌ | Qt, Wt, Crow, Oat++, Drogon |
| 12 | C | ❌ | libmicrohttpd, Mongoose, ulfius |
| 13 | R | ❌ | Shiny, Plumber |
| 14 | Scala | ❌ | Play, Akka HTTP, http4s |
| 15 | Dart | ❌ | Flutter, Shelf, Angel, Dart Frog |
| 16 | Lua | ❌ | Lapis, Sailor, Lapis |
| 17 | Elixir | ❌ | Phoenix, Ash, LiveView |
| 18 | F# | ❌ | Giraffe, Saturn, Falco |
| 19 | Haskell | ❌ | Yesod, Servant, IHP |
| 20 | Clojure | ❌ | Pedestal, Reitit, Fulcro |

### Tier 3: Growing / Specialized (Medium Priority)
| Rank | Language | Framework Ecosystem |
|------|----------|---------------------|
| 21 | OCaml | ❌ | Dream, Opium, Cohttp |
| 22 | Nim | ❌ | Jester, Karax, Sulu |
| 23 | Zig | ❌ | mach, std.http |
| 24 | Crystal | ❌ | Amber, Lucky, Kemal |
| 25 | Julia | ❌ | Genie, HTTP.jl |
| 26 | V | ❌ | vweb, vet |
| 27 | Gleam | ❌ | Lustre, Mist, Wisp |
| 28 | ReasonML | ❌ | ReScript, React |
| 29 | Elm | ❌ | elm-pages, elm-spa |
| 30 | PureScript | ❌ | Halogen, Spork |

### Tier 4: Enterprise / Legacy (Lower Priority)
| Rank | Language | Framework Ecosystem |
|------|----------|---------------------|
| 31 | Perl | ❌ | Mojolicious, Dancer2, Catalyst |
| 32 | Groovy | ❌ | Grails, Micronaut |
| 33 | Visual Basic | ❌ | ASP.NET |
| 34 | Assembly | ❌ | N/A |
| 35 | Fortran | ❌ | N/A |
| 36 | COBOL | ❌ | N/A |
| 37 | Ada | ❌ | AWS/Ada Web Server |
| 38 | Pascal | ❌ | fpWeb, Brook |
| 39 | Lisp/Scheme | ❌ | Hunchentoot, Caveman2 |
| 40 | Prolog | ❌ | SWI-Prolog HTTP |

### Tier 5: Emerging / Niche (Future)
| Rank | Language | Framework Ecosystem |
|------|----------|---------------------|
| 41 | Ballerina | ❌ | Native services |
| 42 | Dark | ❌ | Darklang |
| 43 | Unison | ❌ | Unison Cloud |
| 44 | Roc | ❌ | Roc web |
| 45 | Carbon | ❌ | Experimental |
| 46 | Vale | ❌ | Experimental |
| 47 | Austral | ❌ | Experimental |
| 48 | Koka | ❌ | Experimental |
| 49 | Ante | ❌ | Experimental |
| 50 | Mojo | ❌ | AI-focused |

---

## Architecture Extension Points

### 1. Framework Adapters — Core Extension (`framework-adapters.ts`)

**Current**: 7 adapters implementing `FrameworkAdapter` interface (16 methods)

**Changes needed**:
- **File**: `artifacts/api-server/src/lib/framework-adapters.ts`
- **Lines 18-26**: Expand `FrameworkTypeSchema` enum to include 50+ languages
- **Lines 30-64**: Extend `FrameworkConfigSchema` with language-agnostic fields:
  ```typescript
  language: z.string(),           // e.g., "python", "rust", "go"
  languageVersion: z.string(),    // e.g., "3.11", "1.75", "1.22"
  packageManager: z.string(),     // "npm", "pip", "cargo", "go", "maven", "gradle", "composer"
  buildSystem: z.string(),        // "vite", "webpack", "cargo", "go build", "maven", "gradle"
  testRunner: z.string(),         // "vitest", "pytest", "cargo test", "go test", "mvn test"
  lintCommand: z.string(),        // "eslint", "ruff", "clippy", "golangci-lint", "mvn checkstyle"
  typeChecker: z.string(),        // "tsc", "mypy", "pyright", "cargo check", "go vet"
  ```

- **Lines 135-166**: Extend `FrameworkAdapter` interface with language-agnostic methods:
  ```typescript
  // Language-specific additions
  generatePackageManifest(options: ScaffoldOptions): GeneratedFile;
  generateBuildConfig(options: ScaffoldOptions): GeneratedFile;
  generateTestConfig(options: ScaffoldOptions): GeneratedFile;
  generateLintConfig(options: ScaffoldOptions): GeneratedFile;
  getPackageManager(): string;
  getBuildCommand(): string;
  getTestCommand(): string;
  getLintCommand(): string;
  getTypeCheckCommand(): string;
  ```

- **Lines 172-558**: Create `LanguageFamilyAdapter` abstract base classes per ecosystem:
  - `JsTsBaseAdapter` (existing, extends for 7 frameworks)
  - `PythonBaseAdapter` (pip/pyproject.toml, pytest, ruff, mypy)
  - `JvmBaseAdapter` (Maven/Gradle, JUnit, Checkstyle/SpotBugs)
  - `GoBaseAdapter` (go.mod, go test, golangci-lint)
  - `RustBaseAdapter` (Cargo.toml, cargo test, clippy)
  - `DotNetBaseAdapter` (csproj, dotnet test, dotnet format)
  - `PhpBaseAdapter` (composer.json, phpunit, phpstan)
  - `RubyBaseAdapter` (Gemfile, rspec, rubocop)
  - `SwiftBaseAdapter` (Package.swift, swift test, swiftlint)
  - ... one per language family

### 2. Scaffold Engine — Per-Language Skeletons (`scaffold-engine.ts`)

**Current**: Generates JS/TS skeletons with shadcn/ui corpus (70 components)

**Changes needed**:
- **File**: `artifacts/api-server/src/lib/scaffold-engine.ts`
- **Lines 45-79**: Create per-language `UI_CORPUS_DEPS` equivalents:
  ```typescript
  // Python
  PYTHON_CORPUS_DEPS = {
    "fastapi": "0.109.0",
    "pydantic": "2.6.0",
    "sqlalchemy": "2.0.25",
    "alembic": "1.13.0",
    "pytest": "7.4.0",
    "ruff": "0.1.0",
    "mypy": "1.8.0",
  }
  
  // Rust
  RUST_CORPUS_DEPS = {
    "tokio": "1.38",
    "axum": "0.7",
    "serde": "1.0",
    "sqlx": "0.7",
    "clap": "4.4",
  }
  
  // Go
  GO_CORPUS_DEPS = {
    "github.com/gin-gonic/gin": "v1.9.1",
    "gorm.io/gorm": "v1.25.0",
  }
  ```

- **Lines 105-163**: Create per-language `SKELETON_GAP_FILES`:
  - Python: `pyproject.toml`, `requirements.txt`, `pytest.ini`, `mypy.ini`, `main.py`, `app/__init__.py`
  - Rust: `Cargo.toml`, `src/main.rs`, `src/lib.rs`, `tests/integration.rs`
  - Go: `go.mod`, `main.go`, `go.sum`, `Makefile`
  - Java: `pom.xml` / `build.gradle`, `src/main/java/Application.java`, `src/test/java/ApplicationTest.java`
  - C#: `Project.csproj`, `Program.cs`, `Project.Tests/Project.Tests.csproj`
  - PHP: `composer.json`, `index.php`, `public/index.php`, `tests/Bootstrap.php`
  - Ruby: `Gemfile`, `config.ru`, `app.rb`, `spec/spec_helper.rb`
  - Swift: `Package.swift`, `Sources/main.swift`, `Tests/ProjectTests/ProjectTests.swift`

- **Lines 166-171**: Create per-language `BASE_CORPUS` component libraries:
  - Python: FastAPI routers, Pydantic models, SQLAlchemy models, HTMX/Alpine components
  - Rust: Axum handlers, SQLx models, Askama templates, Leptos/Dioxus components
  - Go: Gin handlers, GORM models, html/template components, templ components
  - Java: Spring controllers, JPA entities, Thymeleaf templates, HTMX fragments
  - C#: Controllers, EF Core entities, Razor components, Blazor components
  - PHP: Laravel controllers, Eloquent models, Blade components, Livewire components
  - Ruby: Rails controllers, ActiveRecord models, ViewComponents, Hotwire components
  - Swift: Vapor routes, Fluent models, Leaf templates, SwiftUI components

- **Lines 243-263**: Copy language-specific component corpus to workspace
- **Lines 265-267**: Generate language-appropriate barrel exports

### 3. Build Tools — Per-Language Verification (`build-tools.ts`)

**Current**: 15 tools (list_files, read_file, edit_file, run_command, screenshot, inspect_console, inspect_dom, inspect_accessibility, git_diff, apply_fix, generate_component, done)

**Changes needed**:
- **File**: `artifacts/api-server/src/lib/build-tools.ts`
- **Lines 1-150**: Add language-aware tool execution:
  - `run_command` auto-detects package manager (npm/pip/cargo/go/maven/gradle/dotnet/composer/bundle)
  - `inspect_console` works with language-specific debuggers
  - `generate_component` routes to language-specific corpus

- **TOOL_DEFINITIONS**: Add language-specific tool variants:
  ```typescript
  {
    name: "run_test",
    description: "Run tests using the project's test runner",
    parameters: { ... }
  },
  {
    name: "run_lint",
    description: "Run linter using the project's linter",
    parameters: { ... }
  },
  {
    name: "run_typecheck",
    description: "Run type checker using the project's type checker",
    parameters: { ... }
  },
  {
    name: "run_build",
    description: "Build the project using the project's build system",
    parameters: { ... }
  }
  ```

### 4. Structured Tools — Per-Language Parsers (`structured-tools.ts`)

**Current**: Parsers for tsc, vitest, eslint, build (JS/TS only)

**Changes needed**:
- **File**: `artifacts/api-server/src/lib/structured-tools.ts`
- **Lines 200-230**: Add `parsePythonOutput` (mypy, pyright, pytest, ruff)
- **Lines 232-267**: Add `parseRustOutput` (cargo check, cargo test, cargo clippy)
- **Lines 269-290**: Add `parseGoOutput` (go build, go test, go vet, golangci-lint)
- **Lines 292-315**: Add `parseJvmOutput` (mvn/gradle compile, test, checkstyle, spotbugs)
- **Lines 292-315**: Add `parseDotNetOutput` (dotnet build, dotnet test, dotnet format)
- **Lines 292-315**: Add `parsePhpOutput` (phpstan, psalm, phpunit, phpcs)
- **Lines 292-315**: Add `parseRubyOutput` (rubocop, rspec, rails test)
- **Lines 292-315**: Add `parseSwiftOutput` (swift build, swift test, swiftlint)

- **Lines 333-390**: Modify `verifyWorkspace` to dispatch per-language:
  ```typescript
  async function verifyWorkspace(projectId: string, workspaceId?: string): Promise<StructuredToolResult> {
    const language = await detectLanguage(workspacePath);
    const verifier = getVerifier(language);
    return verifier(workspacePath);
  }
  ```

### 5. Build Agent — Per-Language System Prompts (`build-agent.ts`)

**Current**: Single system prompt with JS/TS-specific rules

**Changes needed**:
- **File**: `artifacts/api-server/src/lib/build-agent.ts`
- **Lines 140-200**: Create `buildAgentSystemPrompt(workspaceId, language)` that injects:
  - Language-specific quality standards
  - Language-specific testing patterns
  - Language-specific dependency management rules
  - Language-specific error handling patterns

- **Example Python System Prompt Additions**:
  ```
  ## Python Quality Rules (HARD)
  - Use type hints on all public functions (mypy --strict)
  - Write tests with pytest; target >80% coverage
  - Use ruff for linting; fix all errors before committing
  - Prefer pathlib over os.path; use dataclasses/pydantic for data
  - NEVER invent a dependency version — use pyproject.toml pinned versions
  - Follow PEP 8, PEP 257; use Google/NumPy docstring style
  - Async/await for I/O; avoid sync blocking in async code
  ```

- **Example Rust System Prompt Additions**:
  ```
  ## Rust Quality Rules (HARD)
  - Compile with `cargo check` — zero warnings (deny warnings in CI)
  - Write tests with `#[test]` and `#[tokio::test]`; target >80% coverage
  - Use clippy; fix all warnings before committing
  - Prefer `Result<T, E>` over panic; use `anyhow`/`thiserror` for errors
  - NEVER invent a dependency version — use Cargo.toml pinned versions
  - Follow Rust API Guidelines; document public items with `///`
  - Use `async`/`await` with tokio; avoid blocking in async contexts
  ```

- **Example Go System Prompt Additions**:
  ```
  ## Go Quality Rules (HARD)
  - Run `go vet` and `golangci-lint` — zero issues
  - Write tests with `*_test.go`; target >80% coverage
  - Use `gofmt`/`goimports`; run before every commit
  - NEVER invent a dependency version — use go.mod pinned versions
  - Handle errors explicitly; no naked returns in public APIs
  - Follow Effective Go; document exported identifiers
  - Use context.Context for cancellation/timeout
  ```

### 6. Language Detection (`detectLanguage.ts` - NEW FILE)

**New file**: `artifacts/api-server/src/lib/detect-language.ts`

```typescript
export async function detectLanguage(workspacePath: string): Promise<LanguageType> {
  // Check for language-specific marker files in priority order
  const markers = [
    { file: "Cargo.toml", language: "rust" },
    { file: "go.mod", language: "go" },
    { file: "pyproject.toml", language: "python" },
    { file: "requirements.txt", language: "python" },
    { file: "pom.xml", language: "java" },
    { file: "build.gradle", language: "java" },
    { file: "build.gradle.kts", language: "kotlin" },
    { file: "*.csproj", language: "csharp" },
    { file: "composer.json", language: "php" },
    { file: "Gemfile", language: "ruby" },
    { file: "Package.swift", language: "swift" },
    { file: "mix.exs", language: "elixir" },
    { file: "rebar.config", language: "erlang" },
    { file: "package.json", language: "javascript" }, // fallback to JS/TS
  ];
  
  for (const { file, language } of markers) {
    if (await glob(file, { cwd: workspacePath })) return language;
  }
  return "javascript"; // default
}
```

### 7. Framework Registry — Dynamic Registration (`framework-registry.ts`)

**Current**: Static registry of 7 adapters

**Changes needed**:
- **File**: `artifacts/api-server/src/lib/framework-registry.ts` (NEW or extend existing)
- Dynamic adapter registration per language
- Plugin system for community-contributed adapters
- Auto-discovery from `framework-generators/` directory

---

## Implementation Phases

### Phase 1: Foundation — Language Detection & Core Abstractions (Week 1-2)
**Goal**: Core infrastructure for multi-language support

**Tasks**:
1. Create `detect-language.ts` with 50+ language detection
2. Extend `FrameworkConfigSchema` with language-agnostic fields
3. Create `LanguageFamilyAdapter` abstract base classes (10 families)
4. Create `framework-registry.ts` for dynamic adapter registration
5. Add language field to `ScaffoldOptions` interface
6. Update `getFrameworkAdapter` to route by language + framework

**Files**:
- `artifacts/api-server/src/lib/detect-language.ts` (NEW)
- `artifacts/api-server/src/lib/framework-adapters.ts` (extend)
- `artifacts/api-server/src/lib/framework-registry.ts` (NEW)
- `artifacts/api-server/src/lib/language-families/` (NEW directory)
  - `python-adapter.ts`, `rust-adapter.ts`, `go-adapter.ts`, `jvm-adapter.ts`, `dotnet-adapter.ts`, `php-adapter.ts`, `ruby-adapter.ts`, `swift-adapter.ts`, `js-ts-adapter.ts` (refactor existing)

**Verification**: `detectLanguage` correctly identifies 50 test projects

---

### Phase 2: Python Ecosystem — Full Support (Week 2-3)
**Goal**: Complete Python support (Django, FastAPI, Flask, Streamlit)

**Tasks**:
1. Create `PythonBaseAdapter` with:
   - `generateScaffold()` → pyproject.toml, requirements.txt, pytest.ini, mypy.ini
   - `generatePackageManifest()` → pyproject.toml with pinned deps
   - `generateBuildConfig()` → (none needed for Python)
   - `generateTestConfig()` → pytest.ini, conftest.py
   - `generateLintConfig()` → ruff.toml, pyproject.toml [tool.ruff]
2. Create Python component corpus:
   - FastAPI routers, Pydantic models, SQLAlchemy models
   - HTMX + Alpine.js components for frontend
   - Jinja2 templates, Starlette middleware
3. Create `PYTHON_CORPUS_DEPS` (20+ pinned packages)
4. Create Python `SKELETON_GAP_FILES` (8 files)
5. Add Python parsers to `structured-tools.ts`:
   - `parseMypyOutput`, `parsePyrightOutput`, `parsePytestOutput`, `parseRuffOutput`
6. Add Python system prompt to `build-agent.ts`
7. Add Python verification to `verifyWorkspace`

**Files**:
- `artifacts/api-server/src/lib/language-families/python-adapter.ts` (NEW)
- `artifacts/api-server/src/lib/scaffold-engine.ts` (add Python deps/gaps/corpus)
- `artifacts/api-server/src/lib/structured-tools.ts` (add Python parsers)
- `artifacts/api-server/src/lib/build-agent.ts` (add Python system prompt)
- `artifacts/api-server/src/lib/python-corpus/` (NEW - component templates)

**Verification**: 
- `writeScaffoldWorkspace(..., "python", "fastapi")` creates runnable FastAPI project
- `verifyWorkspace` runs mypy + pytest + ruff + build (uv/pip install)
- 5-app benchmark: Python SaaS, Todo, Dashboard, Chat, Editor all pass

---

### Phase 3: Rust Ecosystem — Full Support (Week 3-4)
**Goal**: Complete Rust support (Axum, Actix, Leptos, Dioxus, Tauri)

**Tasks**:
1. Create `RustBaseAdapter` with Cargo.toml generation
2. Create Rust component corpus (Axum handlers, SQLx models, Askama templates, Leptos/Dioxus components)
3. Create `RUST_CORPUS_DEPS` (15+ pinned crates)
4. Create Rust `SKELETON_GAP_FILES` (6 files)
5. Add Rust parsers to `structured-tools.ts`:
   - `parseCargoCheckOutput`, `parseCargoTestOutput`, `parseCargoClippyOutput`
6. Add Rust system prompt to `build-agent.ts`
7. Add Rust verification to `verifyWorkspace`

**Files**:
- `artifacts/api-server/src/lib/language-families/rust-adapter.ts` (NEW)
- `artifacts/api-server/src/lib/scaffold-engine.ts` (add Rust deps/gaps/corpus)
- `artifacts/api-server/src/lib/structured-tools.ts` (add Rust parsers)
- `artifacts/api-server/src/lib/build-agent.ts` (add Rust system prompt)
- `artifacts/api-server/src/lib/rust-corpus/` (NEW)

**Verification**: Runnable Axum/Leptos projects, cargo check/test/clippy all pass

---

### Phase 4: Go Ecosystem — Full Support (Week 4-5)
**Goal**: Complete Go support (Gin, Echo, Fiber, Wails, Templ)

**Tasks**:
1. Create `GoBaseAdapter` with go.mod generation
2. Create Go component corpus (Gin handlers, GORM models, html/template, Templ components)
3. Create `GO_CORPUS_DEPS` (10+ pinned modules)
4. Create Go `SKELETON_GAP_FILES` (5 files)
5. Add Go parsers to `structured-tools.ts`:
   - `parseGoBuildOutput`, `parseGoTestOutput`, `parseGoVetOutput`, `parseGolangciLintOutput`
6. Add Go system prompt to `build-agent.ts`
7. Add Go verification to `verifyWorkspace`

**Files**: (similar pattern)

---

### Phase 5: JVM Ecosystem — Java/Kotlin/Scala (Week 5-7)
**Goal**: Complete JVM support (Spring Boot, Quarkus, Ktor, Play)

**Tasks**:
1. Create `JvmBaseAdapter` with Maven/Gradle support
2. Create JVM component corpus (Spring controllers, JPA entities, Thymeleaf, Jetpack Compose)
3. Create `JVM_CORPUS_DEPS` (Maven coordinates)
4. Create JVM `SKELETON_GAP_FILES`
5. Add JVM parsers (mvn/gradle output parsing)
6. Add JVM system prompts
7. Add JVM verification

---

### Phase 6: .NET Ecosystem — C#/F# (Week 7-8)
**Goal**: Complete .NET support (ASP.NET Core, Blazor, MAUI)

---

### Phase 7: PHP/Ruby/Swift/Elixir (Week 8-10)
**Goal**: Complete support for these ecosystems

---

### Phase 8: Remaining 30+ Languages (Week 10-14)
**Goal**: Add Tier 3-5 languages using shared patterns

**Strategy**: For each language, create minimal adapter with:
- Package manifest generation
- Build/test/lint command detection
- Basic scaffold (hello world + test)
- Verification parser for that language's tools
- System prompt with language-specific quality rules

---

### Phase 9: Cross-Language Features & Polish (Week 14-16)
**Goal**: Unified experience across all languages

**Tasks**:
1. Universal `generate_component` tool that routes to language-specific corpus
2. Cross-language project templates (monorepos, polyglot)
3. Language-agnostic IR for component generation (AST-based)
4. Unified verification dashboard
5. Language-specific benchmark suite (5 apps × 50 languages = 250 test cases)
6. Documentation & migration guides

---

## System Prompts Per Language (Non-Technical Quality Standards)

Each language gets a **system prompt injection** in `buildAgentSystemPrompt()` covering:

| Aspect | Python | Rust | Go | Java | C# | PHP | Ruby | Swift |
|--------|--------|------|----|------|----|-----|------|-------|
| **Type Safety** | mypy --strict / pyright | cargo check (deny warnings) | go vet + golangci-lint | javac -Xlint:all | dotnet build / analyzers | phpstan level 8 | steep / sorbet | swift build -Xswiftc -warnings-as-errors |
| **Testing** | pytest >80% cov | cargo test >80% cov | go test -cover >80% | JUnit >80% cov | xUnit >80% cov | PHPUnit >80% cov | RSpec >80% cov | XCTest >80% cov |
| **Linting** | ruff (all rules) | clippy (all) | golangci-lint (all) | checkstyle/spotbugs | dotnet format + analyzers | phpcs (PSR-12) | rubocop (all) | swiftlint (all) |
| **Deps** | pyproject.toml pinned | Cargo.toml pinned | go.mod pinned | pom.xml/gradle pinned | csproj pinned | composer.json locked | Gemfile.lock | Package.swift resolved |
| **Style** | PEP 8/257, Google docstrings | Rust API Guidelines, /// docs | Effective Go, godoc | Google Java Style | Microsoft C# conventions | PSR-12, PHPDoc | Ruby Style Guide, YARD | Swift API Design Guidelines |
| **Error Handling** | Result types, exceptions | Result<T,E>, anyhow/thiserror | Explicit error returns | Checked exceptions + Result | Exceptions + Result | Exceptions + Result | Exceptions + Result | do/try/catch, Result |

---

## Verification Criteria Per Language

Each language must pass the **5 Live Counters** (from PHASES.md):

1. **Files on disk** — Scaffold creates runnable project structure
2. **toolResults non-empty** — Agent executes real commands in that language
3. **Leaves exploring** — Agent doesn't stall in initial state
4. **verify_start events + bad file flips ok false** — Verification catches real errors
5. **0-file step never ok:true** — Done gate requires actual files + passing verification

**Plus per-language benchmarks** (5 apps each):
- SaaS Landing Page (web framework)
- Todo App with Persistence (DB + API)
- Dashboard (data viz + real-time)
- Chat Widget (WebSocket/SSE)
- Markdown Editor (rich text + preview)

---

## File:Line References for Key Changes

| Component | File | Lines | Change Type |
|-----------|------|-------|-------------|
| FrameworkTypeSchema | framework-adapters.ts | 18-26 | Extend enum |
| FrameworkConfigSchema | framework-adapters.ts | 30-64 | Add language fields |
| FrameworkAdapter interface | framework-adapters.ts | 135-166 | Add methods |
| LanguageFamilyAdapter bases | framework-adapters.ts | 172-558 | New abstract classes |
| UI_CORPUS_DEPS | scaffold-engine.ts | 45-79 | Per-language maps |
| SKELETON_GAP_FILES | scaffold-engine.ts | 105-163 | Per-language gaps |
| BASE_CORPUS | scaffold-engine.ts | 166-171 | Per-language components |
| writeScaffoldWorkspace | scaffold-engine.ts | 187-282 | Multi-language routing |
| TOOL_DEFINITIONS | build-tools.ts | ~50-200 | Add language tools |
| executeTool | build-tools.ts | ~200-500 | Language-aware execution |
| parseTypeScriptOutput | structured-tools.ts | 200-230 | Add parsers per language |
| parseVitestOutput | structured-tools.ts | 232-267 | Add parsers per language |
| parseESLintOutput | structured-tools.ts | 269-290 | Add parsers per language |
| parseBuildArtifacts | structured-tools.ts | 292-315 | Add per-language artifacts |
| verifyWorkspace | structured-tools.ts | 333-390 | Dispatch by language |
| buildAgentSystemPrompt | build-agent.ts | ~140-200 | Inject per-language rules |
| AgentConfig | build-agent.ts | 41-65 | Add language field |
| detectFramework | framework-adapters.ts | 610-867 | Extend for 50 languages |

---

## Budget: $0 (All Free Tiers / Open Source)

- Language detectors: Pure Node.js file system checks
- Verification: Local tool execution (tsc, cargo, go, mvn, dotnet, python -m)
- Component corpora: Open source (shadcn ports, community libraries)
- Templates: Generated from existing open source starters
- No API calls, no paid services, no free trials

---

## Success Metrics

| Metric | Target |
|--------|--------|
| Languages supported | 50+ |
| Frameworks per language | 2-3 minimum |
| Benchmark apps passing | 5/5 per language |
| Verification counters green | 5/5 per language |
| Scaffold build success rate | 100% (pinned deps) |
| Zero `|| true` in any verification | Enforced |
| System prompt quality rules | 1 per language |

---

## Next Steps

1. **Approve this plan** → Begin Phase 1 implementation
2. **Phase 1 deliverable**: Working language detection + 10 language family base adapters
3. **Iterate** through phases, running harness after each
4. **Final validation**: 50 languages × 5 apps = 250 benchmark runs, all passing